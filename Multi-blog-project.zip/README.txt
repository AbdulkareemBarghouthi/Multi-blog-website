There are two ways to access the code

A)Either visit 
https://multi-blog-website.appspot.com/blog/signup
this path is to signup page
other paths are

1) https://multi-blog-website.appspot.com/blog/login
2) https://multi-blog-website.appspot.com/blog/main
3) https://multi-blog-website.appspot.com/blog/upload
others are accessed through out the website

B) Create a google cloud account and create a project
1) name this project the "Multi-Blog-Website
2) then open your cmd go to the directory of the project (source code)
3) run gcloud init
4) it will prompt you into different things, choose the project you have created in the console
5) name it and wait for it to be created
6) after you're done run dev_appserver.py . and on http://localhost:8080 you'll find the website with the formerly mentioned paths
